const x = 4;
const y = 7;

console.log();