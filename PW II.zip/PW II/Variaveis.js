// exercicio.1 //
let x;
console.log(x);

// exercicio.2 //
const number = 42;
console.log(number);

// exercicio.3 //
var y = 1; 
console.log(y);
